<?php

echo "
<!DOCTYPE html>
<html>
<head>
  <meta charset='UTF-8>
  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
  <meta name='generator' content='MTransfer.lk - Mutual Transfer For Teachers And Nurses'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='shortcut icon' href='assets/images/logo-12-256x256-48.png' type='image/x-icon'>
  <meta name='description' content='Mutual Transfer For Teachers And Nurses'>
  <title>".$websiteName."</title>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:700,400&amp;subset=cyrillic,latin,greek,vietnamese'>
  <link rel='stylesheet' href='assets/bootstrap/css/bootstrap.min.css'>
  <link rel='stylesheet' href='assets/animate.css/animate.min.css'>
  <link rel='stylesheet' href='assets/socicon/css/socicon.min.css'>
  <link rel='stylesheet' href='assets/mobirise/css/style.css'>
  <link rel='stylesheet' href='assets/mobirise/css/mbr-additional.css' type='text/css'>
  <link href=".$template." rel='stylesheet' type='text/css' />
  <link rel='stylesheet' href='assets/css/style.css'>
</head>
<body>";

?>
