( function( $ ) {

	$( document ).ready(function($){

		$('.travel-eye-featured-trips').slick();

	});

} )( jQuery );
