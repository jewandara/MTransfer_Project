( function( $ ) {

  // Add Upgrade button.
  $('.preview-notice').prepend('<span id="btn-wen-upgrade"><a target="_blank" class="button btn-upgrade" href="' + Travel_Eye_Customizer_Object.updrade_button_link + '">' + Travel_Eye_Customizer_Object.updrade_button_text + '</a></span>');

} )( jQuery );
