( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#travel-eye-settings-metabox-container' ).easytabs({
			updateHash: false,
			animate: false
		});

	});

} )( jQuery );
