<?php
/// include widgets


// incude Category Post
require_once( 'widget-category.php' );

// incude Social Icons
require_once( 'widget-social-icons.php' );

?>